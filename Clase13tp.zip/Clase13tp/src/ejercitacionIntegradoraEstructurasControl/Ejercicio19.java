/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercitacionIntegradoraEstructurasControl;

import java.util.Scanner;

/**
 *
 * @author jorge
 */
public class Ejercicio19 {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        System.out.print("ingrese numero: ");
        int numero = lector.nextInt();
        
        System.out.print("ingrese simbolo: ");
        String simbolo = lector.next();
        
        for (int asterisco = 1; asterisco <= numero; asterisco++)
        {
            System.out.print(simbolo);
        }

        System.out.println();

        for (int asterisco = 1; asterisco <= numero - 2; asterisco++) {
            System.out.print(simbolo);
            
            for (int espacio = 1; espacio <= numero - 2; espacio++) 
            {
                System.out.print(" ");
            }
            
            System.out.print(simbolo);
            System.out.println();
        }

        for (int asterisco = 1; asterisco <= numero; asterisco++) 
        {
            System.out.print(simbolo);
        }
        
        }
    }

