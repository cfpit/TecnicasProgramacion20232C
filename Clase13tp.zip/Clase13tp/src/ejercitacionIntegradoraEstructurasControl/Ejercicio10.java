/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercitacionIntegradoraEstructurasControl;

import java.util.Scanner;

/**
 *
 * @author Jorge
 */
public class Ejercicio10 {
    public static void main(String[] args) {
        int opcion=0;
        
        Scanner lector=new Scanner(System.in);
        do {
                
        System.out.println("Menu de recomendaciones:");
        
        System.out.println("1. Literatura");
        
        System.out.println("2. Cine");
        
        System.out.println("3. Música");
        
        System.out.println("4. Videojuegos");
        
        System.out.println("5. Salir");
        
        System.out.print("Ingrese opcion, por favor: ");
        opcion=lector.nextInt();
        
        if (opcion>0 && opcion<6) {
            
            switch (opcion) {
                case 1:
                    System.out.println("Lecturas recomendables:"); 
                    System.out.println("");
                    System.out.println("+ Esperándolo a Tito y otros cuentos de fútbol (Eduardo Sacheri)");
                    System.out.println("+ El juego de Ender (Orson Scott Card)");
                    System.out.println("+ El sueño de los héroes (Adolfo Bioy Casares)"); 
                    System.out.println("--------------------------------------");
                    break;
                    
                case 2:
                    
                    System.out.println("Películas recomendables:"); 
                    System.out.println("");
                    System.out.println("+ Matrix (1999)");
                    System.out.println("+ El último samurai (2003)");
                    System.out.println("+ Cars (2006))");  
                    System.out.println("--------------------------------------");
                    break;
                    
                case 3:
                    
                    System.out.println("Discos recomendables:"); 
                    System.out.println("");
                    System.out.println("+ Despedazado por mil partes (La Renga, 1996)");
                    System.out.println("+ Bufalo (La Mississippi, 2008)");
                    System.out.println("+ Gaia (Mägo de Oz, 2003)");
                    System.out.println("--------------------------------------");
                    break;
                    
                 case 4:
                    
                    System.out.println("Videojuegos clásicos recomendables:"); 
                     System.out.println("");
                    System.out.println("+ Día del tentáculo (LucasArts, 1993)");
                    System.out.println("+ Terminal Velocity (Terminal Reality/3D Realms, 1995)");
                    System.out.println("+ Death Rally (Remedy/Apogee, 1996)");
                    System.out.println("--------------------------------------");
                    break;
                    
                case 5:
                    System.out.println("Adios!");
                    break;
                    
                
               // default:
                    
            }
        
        }//fin if
        else
          System.out.println("Opcion no valida");  
        
        
        } while (opcion!=5);
    } 
}
