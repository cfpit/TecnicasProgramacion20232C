package ejercitacionIntegradoraEstructurasControl;

import java.util.Scanner;

public class Ejercicio24c {
    public static void main(String[] args) {
        /*
            Desarrollar un algoritmo que pida un número al usuario y que por cada 
            carga pregunte si se desea seguir ingresando, de la siguiente forma 
            "¿Desea ingresar otro número? [S/N]". La carga de datos finaliza cuando 
            se detecta una 'n' o 'N'. La computadora debe mostrar la cantidad de 
            números pares ingresados. 
        */
        
        Scanner lector = new Scanner(System.in);
        
        int cantPares = 0;
        int n;
        String rta;
        
        
        do 
        {
            System.out.println("Ingrese un numero: ");
            n = lector.nextInt();
            
            //si n es par...
            if (n % 2 == 0) {
                //...entonces, contabilizo
                cantPares ++;
            }
            
            System.out.println("¿Desea ingresar otro número? [S/N]");
            rta = lector.next();
            
            if (rta.equalsIgnoreCase("n")) {
                break;
            }
            
        } while (true);
        
        System.out.println("cantidad de nros. pares = " + cantPares);
    }
}
