/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercitacionIntegradoraEstructurasControl;

import java.util.Scanner;

/**
 *
 * @author alumno
 * 
 */
public class Ejercicio20 {
    public static void main(String[] args) {
        
        System.out.println("Crear un algoritmo que lea un número entero "
                + "(altura) y a partir de él cree una escalera invertida de "
                + "asteriscos con esa altura");
        
        Scanner lector = new Scanner(System.in);
        
        System.out.print("ingrese altura: ");
        int altura = lector.nextInt();
        
        System.out.print("ingrese simbolo: ");
        String simbolo = lector.next();
        
        int espacio = 0, asterisco = altura;
        
        for (int linea = 1; linea <= altura; linea++) {
            
            //escribimos los espacios iniciales
            for (int espacioLinea = 0; espacioLinea <= espacio ; espacioLinea++) 
            {
                System.out.print(" ");
            }
            
            //escribimos los asteriscos de la escalera
            for (int asteriscoLinea = 1; asteriscoLinea <= asterisco; asteriscoLinea++) 
            {
                System.out.print(simbolo);
            }
            
            //aumentamos los espacios y disminuimos los asteriscos
            asterisco --;
            espacio ++;
            System.out.println(" ");
        }
        
    }
}
