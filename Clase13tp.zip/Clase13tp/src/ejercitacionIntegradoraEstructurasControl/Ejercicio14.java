/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercitacionIntegradoraEstructurasControl;

import java.util.Scanner;

/**
 *
 * @author jorge
 */
public class Ejercicio14 {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        System.out.print("ingrese numero: ");
        int numero = lector.nextInt();
        
        System.out.print("ingrese simbolo: ");
        String simbolo = lector.next();
        
        for (int fila = 1; fila <= numero; fila++) 
        {
            for (int columna = 1; columna <= numero; columna++) 
            {
                System.out.print(simbolo);
            }
            
            System.out.print("\n");//salto de linea
//            System.out.println();//salto de linea
        }
    }
    
}
