package ejercitacionIterativaWhile;

public class Test {
    public static void main(String[] args) {
        /*
            Ejercicio 1 Imprimir los números del 1 al 10 
            uno abajo del otro 
            
        */
        //debugging
        System.out.println("Inicio");
        
        int n = 1;
        while (n <= 10) 
        {
            System.out.println("n = " + n);
            n ++;
        }
        
        System.out.println("fin");
    }
}

