package operadores;

public class Test {
    public static void main(String[] args) {
        System.out.println("operadores aritmeticos: + - * / %");
        
        System.out.println(10 + 5);//15
        System.out.println(20 - 7);//13
        System.out.println(4 * 3);//12
        System.out.println(20 / 5);//4
        
        //resto de una division
        System.out.println(4 % 2);//0
        
        System.out.println(20 / 3);//6
        System.out.println((double)20 / 3);//6,666666666666667
        System.out.println(String.format("%.2f", (double)20 / 3));//6,67
        
        int n1 = 10;
        int n2 = 5;
        
        System.out.println("n1 + n2 = " + n1 + n2);//105
        System.out.println("n1 + n2 = " + (n1 + n2));//15
        
        System.out.println("operadores relacionales");
        
        System.out.println(n1 > n2);//true
        System.out.println(n1 < n2);//false
        System.out.println(n1 >= n2);//true
        System.out.println(n1 <= n2);//false
        System.out.println(n1 == n2);//false
        System.out.println(n1 != n2);//true
        
        int n = 100000;
        
        System.out.println("operadores incrementales");
        
        int numero = 1;
        System.out.println("numero = " + numero);//numero = 1
        
        numero ++;//incremento unitario -> suma de a 1
        System.out.println("numero = " + numero);//numero = 2
        
        numero += 1;//incremento unitario -> suma de a 1
        System.out.println("numero = " + numero);//numero = 3
        
        numero = numero + 1;//incremento unitario -> suma de a 1
        System.out.println("numero = " + numero);//numero = 4
        
        numero --;//decremento unitario -> resta de a 1
        System.out.println("numero = " + numero);//numero = 3
        
        numero += 7;
        System.out.println("numero = " + numero);//numero = 10
        
        numero *= 5;// numero = numero * 5
        System.out.println("numero = " + numero);//numero = 50
        
        numero %= 2;// numero = numero % 2
        System.out.println("numero = " + numero);//numero = 0
        
        System.out.println("post-incremento");
        System.out.println(numero++);//0
        System.out.println(numero);//1
        
        System.out.println("pre-incremento");
        System.out.println(++numero);//1
        System.out.println(numero);//1
        
        
        System.out.println("operadores logicos");
        System.out.println(true & true);//true
        System.out.println(true & false);//false
        System.out.println(true | false);//true
        System.out.println(false | false);//false
        System.out.println(!false);//true
        System.out.println(!true);//false
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}








