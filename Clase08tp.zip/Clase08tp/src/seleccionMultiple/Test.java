package seleccionMultiple;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        //ingreso del nombre x teclado
        System.out.println("Decime tu nombre: ");
        String nombre = lector.next();
        
        //condicional de seleccion multiple
        switch (nombre.toLowerCase()) {
            case "juan":
                System.out.println("Como estas Juancito!");
                break;
            case "carlos":
                System.out.println("Que contas Charly!");
                break;
            case "maria":
                System.out.println("Buen dia Mary!");
                break;
            default:
                System.out.println("Hola "+ nombre + " !");
                break;
        }
    }
}
