

package tiposDatos;

import java.util.Scanner;


public class Test {
    public static void main(String[] args) {
        System.out.println("Tipo de dato cadena de caracteres");
        
        
        //esto es un comentario de linea 
        
        
        /*
            esto es
            un comentario
            de bloque
        */
        
        //declaro e inicializo una variable de tipo cadena
        String direccion = "Medrano 162 CABA";
        System.out.println(direccion);
        
        
        
        System.out.println("Tipo de dato entero");
        
        //declaro una variable de tipo entero
        int n;
        
        //inicializo la variable n
        n = 10;
        
        //muestro el valor de n
        System.out.println("n = " + n);
        
        double longitud = 4.57;
        System.out.println("La medida es de      " + longitud + " metros");
        
        float precio = 189.90f;
        System.out.println("El precio es de " + precio + " U$s");
        
        char simbolo = '@';
        System.out.println("El simbolo es " + simbolo);
        
        //cambio el valor de la variable simbolo
        simbolo = 'J';
        System.out.println("El simbolo ahora es " + simbolo);
        
        boolean abierto = false; // valor alternativo: false
        if (abierto) 
        {
            System.out.println("Negocio abierto");
        } 
        else 
        {
            System.out.println("Negocio cerrado");
        }
        
        int cantidadDePuertas = 5;
        
        System.out.println("Constantes");
        
        //creo un ojeto de la clase Scanner q leera dsd el teclado
        //System.in = teclado
        //Scanner(System.in) es el metodo constructor de objetos
        //new Scanner(System.in) es un objeto de la clase Scanner
        //lector es una variable q guarda el objeto
        Scanner lector = new Scanner(System.in);
        
        final double PI = 3.14;
//        int radio = 4;

        System.out.println("Ingrese el radio del circulo: ");
        int radio = lector.nextInt();
        
//        PI = 10;//no se puede modificar el valor de una constante
        
//        double areaCirculo = PI * radio * radio;
        double areaCirculo = PI * Math.pow(radio, 2);
        
        System.out.println("El area es de " + areaCirculo + " cm. cuadrados");
        
    }
}


