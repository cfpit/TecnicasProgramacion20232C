package EjecitacionEstructurasCondicionales;

import java.util.Scanner;

public class Ejercicio7 {

    public static void main(String[] args) {
        //creo un objeto Scanner q lee dsd teclado
        Scanner lector = new Scanner(System.in);

        //ingreso de datos
        System.out.println("Tipo(a-b)?: ");
        String ti = lector.next();

        System.out.println("Tamaño(1-2)?: ");
        int ta = lector.nextInt();

        System.out.println("Precio x kilo: ");
        double p = lector.nextDouble();

        System.out.println("Cantidad de kilos: ");
        int k = lector.nextInt();

        //logica
        if (ti.equals("a")) 
        {
            if (ta == 1) 
            {
                System.out.println("total= " + (p + 0.2) * k + " $");
            } 
            else 
            {
                System.out.println("total= " + (p + 0.3) * k + " $");
            }
        } 
        else 
        {
            if (ta == 1) 
            {
                System.out.println("total= " + (p - 0.3) * k + " $");
            } 
            else 
            {
                System.out.println("total= " + (p - 0.5) * k + " $");
            }
        }
        
//        String.format("%.2f", valor);
    }
}
