package arrays;
import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        //declaro el array de edades
        int [] edades;
//        
//        //instancio en la RAM el array -> 20 bytes
        edades = new int [5];
//        
//        //inicializo el array
        edades[0] = 1;
        edades[1] = 3;
        edades[2] = 8;
//        edades[3] = 23;
//        edades[4] = 99;

//        int [] edades = {1,3,8,23,99};
        
        System.out.println("El valor en el indice 3 es " + edades[3]);
        
        System.out.println("Longitud del array = " +  edades.length);
        
        //Puedo declarar e instanciar en una sola linea
        String [] marcas = new String[3];
        
        //inicializo el array marcas
        marcas[0] = "Ford";
        marcas[1] = "Chevrolet";
        marcas[2] = "Audi";
        
        System.out.println("El valor en el indice 2 es " + marcas[2]);
        
        
        Arrays.sort(marcas);//orden alfabetico
        System.out.println("Contenido: " + Arrays.toString(marcas));
        
        System.out.print("La posicion de la marca Ford es: ");
        System.out.println(Arrays.binarySearch(marcas, "Ford"));
    }
}















