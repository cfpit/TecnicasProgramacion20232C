package arrays;

import java.util.Scanner;

public class Ejercicio {
    public static void main(String[] args) {
        /*
            Ingresar por teclado 5 edades y almacenarlas en un array.
            Informar la maxima edad, la minima edad y el promedio.
        */
        
        Scanner lector = new Scanner(System.in);
        
        //declaro e instancio en la RAM el array -> 20 bytes
        int [] edades = new int [5];
        
        //variables auxiliares
        int max = 0, total = 0; 
//        int min =89765;
        int min =   Integer.MAX_VALUE;
//        System.out.println(Integer.MAX_VALUE);
        
        //bucle
        for (int i = 0; i < edades.length; i++) {
            System.out.println("Ingresa la edad Nro " + (i + 1) + ": ");
            edades[i] = lector.nextInt();
            
            //Si es el 1er ingreso, el max y min valen lo mismo
            if (i == 0) {
                max = min = edades[i];
            }
            
            //totalizo
            total = total + edades[i];
            
            //maximo
            if (max < edades[i]) {
                max = edades[i];
            }
            
            //minimo
            if (min > edades[i]) {
                min = edades[i];
            }
        }
        
        System.out.println("Mayor = " +  max + " años");
        System.out.println("Menor = " +  min + " años");
        System.out.println("Promedio = " +  total/edades.length + " años");
         
    }
}












