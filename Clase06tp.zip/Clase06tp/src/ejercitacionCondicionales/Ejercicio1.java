package ejercitacionCondicionales;

import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        //ingreso de datos
        System.out.println("n1 = ");
        int n1 = lector.nextInt();
        
        System.out.println("n2 = ");
        int n2 = lector.nextInt();
        
        if (n1 > n2) 
        {
            System.out.println("n1 es el mayor");
        } 
        else 
        {
            if (n2 > n1) 
            {
                System.out.println("n2 es el mayor");
            } 
            else 
            {
                System.out.println("son iguales");
            }
        }
        
        
        
        
    }
}
