package inicio;


public class Test {
    public static void main(String[] args) {
        System.out.println("hola Mundo!!");
    }
}
