package ejercitacionEstructurasIterativas;

public class Ejercicio4 {

    public static void main(String[] args) {
        /*
            Ejercicio 4
            Imprimir los números del 1 al 10 sin imprimir 
            números 2,5 y 9 uno abajo del otro
         */
        
//        int n = 1;
//
//        while (n <= 10) 
//        {
//            if (n != 2 && n != 5 && n != 9) 
//            {
//                System.out.println("n = " + n);
//            }    
//            n ++;
//        }

        for (int i = 1; i <= 10; i++) 
        {
//            if (i != 2 && i != 5 && i != 9) 
            if (!(i == 2 || i == 5 || i == 9)) 
            {
                System.out.println("i = " + i);
            }
        }
        
        

    }
}
