package ejercitacionEstructurasIterativas;

public class Ejercicio6 {
    public static void main(String[] args) {
        
        /* Ejercicio 6 Imprimir la suma de los números del 1 al 10 */
        int suma = 0;
        
        for (int i = 1; i < 11; i++) 
        {
            suma = suma + i;
            System.out.println("suma = " + suma);
        }
        
        
        
        
        
    }
}
