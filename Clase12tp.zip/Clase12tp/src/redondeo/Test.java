package redondeo;

public class Test {
    public static void main(String[] args) {
        // 3.141592653589793
        System.out.println("Valor de pi = " + Math.PI);
        
        System.out.println("3 a la 4 = " + Math.pow(3, 4));
        
        System.out.println("raiz de 14 = " + Math.sqrt(14));
        
        
        
        System.out.println("pi redondeado = " +
                String.format("%.2f", Math.PI));//3.14
        
    }
}
