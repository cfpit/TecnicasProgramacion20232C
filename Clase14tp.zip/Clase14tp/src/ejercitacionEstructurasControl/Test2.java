package ejercitacionEstructurasControl;

import java.util.Scanner;

public class Test2 {
    public static void main(String[] args) {
        /*
            Ingresar x teclado 5 edades. Informar el mayor
            y el promedio de edad
        */
        
        Scanner lector = new Scanner(System.in);
        
        int contadorIngresos = 0, total = 0, cantidadMayores = 0;
        
        do 
        {
            System.out.println("Ingresa una edad: ");
            int edad = lector.nextInt();
            
            if (edad == 0) {
                break;
            }
            
            contadorIngresos ++;
            
            total += edad;
            
            if (edad >= 18) {
                cantidadMayores ++;
            }
            
        } while (true);
        
        if (contadorIngresos != 0) {
            System.out.println("promedio = " + total/(double)contadorIngresos);
        } else {
            System.out.println("No se ingreso ningun valor para calcular el promedio");
        }
        
        System.out.println("cantidad de mayores de edad = " + cantidadMayores);
        
    }
}
