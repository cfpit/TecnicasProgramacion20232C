package ejercitacionEstructurasControl;

import java.util.Scanner;

public class Test { 
    public static void main(String[] args) {
        /*
            Ingresar x teclado 5 edades. Informar el mayor
            y el promedio de edad
        */
        
        Scanner lector = new Scanner(System.in);
        
        int mayor = 0, total = 0, edad = 0;
        
        for (int i = 0; i < 5 ; i++) {
            System.out.println("Te quedan por ingresar : " + (5 - i) + " edades");
            
            System.out.println("Ingresa una edad: ");
            edad = lector.nextInt();
            
            //maximo
            if (mayor < edad) {
                mayor = edad;
            }
            
            //total
            total = total + edad;// total += edad

        }
        
        System.out.println("mayor = " + mayor);
        System.out.println("promedio = " + total/5);
        
        
    }
}














