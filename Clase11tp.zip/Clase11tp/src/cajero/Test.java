package cajero;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        
        Scanner lector = new Scanner(System.in);
        
        int fallidos = 0;
        
        do 
        {
            System.out.print("Ingrese su clave: ");
            String clave = lector.next();
            
            if (clave.equals("123")) {
                break;
            }
            
            fallidos ++;
            System.out.println("chances restantes= "+ (3 - fallidos));
            
           
        } while (fallidos < 3);
        
        if (fallidos == 3) {
            System.out.println("Tarjeta Bloqueada");
        } else {
            System.out.println("Bienvenido al Home Banking!");
        }
    }
}




