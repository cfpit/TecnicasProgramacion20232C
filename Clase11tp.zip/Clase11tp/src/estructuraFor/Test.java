package estructuraFor;

public class Test {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i += 2) {
            System.out.println("i = " + i);
        }
    }
}
