package ejercitacionArrays;

public class Test {
    public static void main(String[] args) {
        
        float [] infla = {0.8f, 0.1f, 0.3f, 0.4f, 0.3f, 0.6f, 0.5f, 0.3f, 0.7f, 0.3f, 0.2f, 0.9f};
        
        //variables auxiliares
        double max = infla[0];
        double min = infla[0];
        
        int mesMax = 0;
        int mesMin = 0;
        
        double total = 0;
        
        for (int i = 0; i < infla.length; i++) {
            //totalizo
            total = total + infla[i]; // total += infla[i]
            
            //maximo
            //si el valor actual en el array es mayor que el maximo hasta entonces...
            if (infla[i] > max) {
                //...asigno el nuevo maximo
                max = infla[i];
                //...guardo el numero de mes en el q se produce la maxima inflacion
                mesMax = i + 1;
            }
            
            //minimo
            //si el valor actual en el array es menor que el minimo hasta entonces...
            if (infla[i] < min) {
                //...asigno el nuevo minimo
                min = infla[i];
                //...guardo el numero de mes en el q se produce la minima inflacion
                mesMin = i + 1;
            }
        }
        
        System.out.println("Inflacion Anual = " + total);
        System.out.println("Promedio = " + total / 12);
        System.out.println("Maxima inflacion = " + max + " Mes = " + mesMax);
        System.out.println("Minima inflacion = " + min + " Mes = " + mesMin);
    }
}
