package matrices;

public class Test {
    public static void main(String[] args) {
        //declaro e instancio una matriz rectangular de enteros
        int [][] m = new int [4][3];//48 bytes
        
        //inicializo la matriz
        m[0][0] = 1;
        m[0][1] = 2;
        m[0][2] = 3;
        m[1][0] = 4;
        m[1][1] = 5;
        m[1][2] = 6;
        m[2][0] = 7;
        m[2][1] = 8;
        m[2][2] = 9;
        m[3][0] = 10;
        m[3][1] = 11;
        m[3][2] = 12;
        
        System.out.println("recorro la matriz y muestro su contenido");
        for (int i = 0; i < m.length; i++) 
        {
            for (int j = 0; j < m[i].length; j++) 
            {
                System.out.println("Fila: " + i + " Columna: " + j + " --> " + m[i][j]);
            }
        }
        
        System.out.println("---------------------------------------");

        System.out.println("Cantidad de filas = " + m.length);
        System.out.println("Cantidad de columnas = " + m[0].length);
        
        
        
        
        
        
    }
}
